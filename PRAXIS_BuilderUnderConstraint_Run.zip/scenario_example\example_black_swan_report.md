# PRAXIS Scenario Report – example_black_swan

## Top Risk Drivers

- **Gas** – Compressor backbone trip (p ≈ 0.429)
- **PowerGrid** – Regional 500 kV corridor loss (p ≈ 0.393)

## Top Events (Fault Tree)

- **Regional_Blackout**: p ≈ 0.170 (95% CI [0.166, 0.173])
- **Any_Backbone_Failure**: p ≈ 0.652 (95% CI [0.648, 0.656])