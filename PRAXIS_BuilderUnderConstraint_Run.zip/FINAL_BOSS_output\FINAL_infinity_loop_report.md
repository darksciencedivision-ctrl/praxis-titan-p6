# PRAXIS Scenario Report – FINAL_infinity_loop

## Top Risk Drivers

- **Gas** – Pipe Failure (p ≈ 0.500)
- **Cyber** – Malware (p ≈ 0.500)
- **Cyber** – Ransomware (p ≈ 0.500)
- **PowerGrid** – Grid Loss (p ≈ 0.500)

## Top Events (Fault Tree)

- **Gate_A**: p ≈ 0.245 (95% CI [0.241, 0.249])
- **Gate_B**: p ≈ 0.746 (95% CI [0.742, 0.750])
- **TE_Certain**: p ≈ 0.749 (95% CI [0.745, 0.753])